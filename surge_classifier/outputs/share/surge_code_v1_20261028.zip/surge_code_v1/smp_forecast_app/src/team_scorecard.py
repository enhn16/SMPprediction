"""발췌본 (팀원 전달용): 원본 smp_forecast_app/src/team_scorecard.py에서 급등 채점에 쓰는 함수 2개만 옮김.
원본은 가격 예측 모듈 전체를 불러와서 이 묶음만으로는 실행되지 않는다."""
import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score


def fa_at(y, s, r):
    """재현율 r을 처음 넘기는 문턱(점수 내림차순)에서 헛경보 수 — 시험 기간 안에서 문턱을 맞춘 값(순위 비교용)."""
    o = np.argsort(-s, kind="stable")
    k = np.searchsorted(np.cumsum(y[o]), int(np.ceil(r * y.sum())))
    return int(((s >= s[o][k]) & (y == 0)).sum())


def drop_stats(y, s):
    return {"PR-AUC": average_precision_score(y, s), "ROC-AUC": roc_auc_score(y, s),
            "헛경보@재현율80%": fa_at(y, s, .8), "헛경보@재현율90%": fa_at(y, s, .9)}
