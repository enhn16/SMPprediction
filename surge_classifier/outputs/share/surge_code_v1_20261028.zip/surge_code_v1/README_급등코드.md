# 급등 경보 — 우리 구현 v1 (2026-10-28)

팀 합의 구성(부호 고정 점수 + 스플라인 로지스틱 + LightGBM 그루터기 평균)을 우리 저장소의 13종 자료로 따로 구현한 것입니다.
**팀원 모델(`spike_simple3.py`)과 수치가 맞지 않아 재구현 예정**이고, 차이를 같이 확인하려고 공유합니다.

## 결과 비교

| | 검증 2024~2025 PR-AUC | 2026 PR-AUC (~10-02, 급등 6일) | 2026 주의 적중/헛경보 | 2026 경보 적중/헛경보 |
|---|---|---|---|---|
| 팀원 `spike_simple3` | 0.114 | 0.249 | 5/6 · 148 | 2/6 · 15 |
| 우리 v1 | 0.242 | 0.043 | 3/6 · 85 | 0/6 · 3 |

- 급등 레이블은 2024-01-01 ~ 2026-10-02의 1,005일 모두 같음(팀원 `daily_scores.csv`의 y와 대조). 차이는 레이블이 아니라 입력 자료와 구현에서 생김.

## 팀원 구현과 다른 점

| 항목 | 팀원 `spike_simple3.py` | 우리 v1 (`surge_classifier/src/team_model.py`) |
|---|---|---|
| SMP·수요예측 | 담당자 파일 `smp_dataset_hourly.csv` | EPSIS 확정값 + data.go.kr API (팀 13종) |
| 날씨 | Open-Meteo 시간별 기온·운량·강수 (2일 전 실행) | 구역별 육상예보 11시분(하늘·강수확률·기온) + Open-Meteo JMA 한낮 운량·일사 |
| 주간 전력수요전망 | 안 씀 | 씀 (최대부하) |
| 피처 | 37개(기본 30 + 가격 계단 7), 세 모델 같은 입력 | 모델마다 다름: 부호 고정 6개, 스플라인 5개(곡선) + 3개(직선), 그루터기 약 45개 |
| 부호 고정 | 19개 입력, 난방도·냉방도(+) 포함 → 1차원 balanced 로지스틱으로 0~1 | 6개 입력(평일×흐림·평일×운량·주간전망·강수확률·전날 최고 비율 +, 휴무일 −), 난방도 없음 |
| 스플라인 | 37개 모두 표준화 → 매듭 4 → 로지스틱 C=0.05, balanced | 5개 변수만 매듭 4 + 직선 3개, C=0.1, balanced, 목표 +20% |
| 그루터기 | 200그루, 학습률 0.03, 잎 20, subsample 0.8, balanced | 100그루, 학습률 0.03, 잎 30, balanced 없음 |
| 평균 | 세 확률(0~1)의 단순 평균 | 세 점수를 학습 구간 기준 z로 바꿔 단순 평균 |
| 검증 방식 | 2024-01 ~ 2025-12 **매달** 앞으로만(그 전달까지 누적 학습) | **해마다**: 2023 → 2024, 2023~2024 → 2025 |
| 문턱 | 0.01 격자, 경보 = 정밀도 50%·적중 2일 이상 | 점수 그대로, 경보 = 정밀도 50%·적중 3일 이상 (없으면 정밀도 최고) |
| 시험 기간 | 2026-01-01 ~ 10-02 | 2026-01-01 ~ 10-18 (팀 공식 기간) + ~10-02 함께 |
| 세부 설정 선택 | 고정값 | 2024~2025 검증으로 후보 116개 중 선택 (`04_team_select_육지.csv`) |

## 실행 (Python 3.12, pandas·scikit-learn·lightgbm·scipy·interpret)

```
python -m surge_classifier.src.team_model select   # 2024~2025 검증으로 세부 선택 → outputs/tables/04_team_select·04_team_choice
python -m surge_classifier.src.team_model test     # 확정 설정으로 2023~2025 재학습 → 2026 채점 → 04_team_test·04_team_daily
```
피처 표(`data/processed/surge_classifier/*.csv`)가 들어 있어서 원자료 없이 위 두 명령은 돌아갑니다. 피처를 원자료부터 다시 만드는 `features.py`·`extra_features.py`·`label_days.py`는 우리 저장소의 `data/raw`가 필요합니다.

## 파일
- `surge_classifier/src/team_model.py` — 이번 구현 (세 모델·검증·문턱·채점)
- `surge_classifier/src/features.py`, `label_days.py` — 피처·레이블 (13종)
- `surge_classifier/src/collect_extra.py`, `extra_features.py` — 추가 자료(JMA 2023 운량, 공급능력·원자력·특보: 13종 밖이라 최종 모델에는 안 씀)
- `surge_classifier/src/models.py`, `ops_surge.py` — 이전 모델(지수식)과 운영 함수
- `surge_classifier/docs/PLAN.md` — 결정 기록 (④절이 이번 작업)
- `surge_classifier/outputs/tables/04_team_*` — 검증 후보표, 확정 설정, 2026 성적, 2026 일별 점수
- `data/processed/surge_classifier/features_육지.csv`, `extra_features_육지.csv` — 일별 피처 표 (2023-01-01 ~ 2026-10-28)
- `common/`, `drop_classifier/src/outlook_features.py` — 공용 코드 일부
- `smp_forecast_app/src/team_scorecard.py` — **발췌본**(채점 함수 2개만)
- API 키(.env)는 들어 있지 않습니다.
