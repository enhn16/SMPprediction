"""급등 피처 후보용 추가 자료 수집 (13종 밖 포함, 2026-10-28 사용자 요청 "모을 수 있는 건 다 모아봐").

공용 수집기(common/collect, 총괄 소유)는 고치지 않고, 원문은 data/raw/surge_extra/ 아래에 따로 둔다.
- supply : EPSIS 일별 최대전력기준 전력수급(설비용량·공급능력·최대전력·공급예비력·예비율·최대전력 시각), 일 단위 실적
           (data.go.kr 15150737 = epsis selectEkgeEpsMep). 15시 판단에는 D-2일분까지 확실 (D-1 최대는 저녁일 수 있음)
- source : 전력거래소 발전원별 5분 실적 2023분 (common.collect.kpx_power_source의 함수 재사용, 2024~는 공용 폴더에 이미 있음)
- warn   : 기상청 API허브 특보 발표 이력 (wrn_met_data)

실행: python -m surge_classifier.src.collect_extra [supply|source|warn ...]
"""
import os
import sys
import time
from datetime import date

import pandas as pd
import requests

from common.config import RAW_DIR

OUT = RAW_DIR / "surge_extra"
EPSIS_PAGE = "https://epsis.kpx.or.kr/epsisnew/selectEkgeEpsMepChart.do?menuId=030100"
EPSIS_URL = "https://epsis.kpx.or.kr/epsisnew/selectEkgeEpsMep.ajax"


def supply(start: str = "2022-11-01", end: str | None = None):
    """연 단위로 나눠 받아 원문 저장 → epsis_supply_{연}.txt"""
    end = end or date.today().isoformat()
    d = OUT / "epsis_supply"
    d.mkdir(parents=True, exist_ok=True)
    s = requests.Session()
    s.headers["User-Agent"] = "Mozilla/5.0"
    s.get(EPSIS_PAGE, timeout=60)
    for y in range(int(start[:4]), int(end[:4]) + 1):
        a = max(pd.Timestamp(start), pd.Timestamp(f"{y}-01-01"))
        b = min(pd.Timestamp(end), pd.Timestamp(f"{y}-12-31"))
        r = s.post(EPSIS_URL, data={"beginDate": f"{a:%Y%m%d}", "endDate": f"{b:%Y%m%d}", "selYear": "", "selMonth": ""},
                   timeout=180)
        r.raise_for_status()
        (d / f"epsis_supply_{y}.txt").write_text(r.text, encoding="utf-8")
        print(f"공급능력 {y}: {r.text.count('gridData.push')}일", flush=True)
        time.sleep(1)


def source(start: str = "2023-01-01", end: str = "2023-12-31"):
    from common.collect import kpx_power_source as ps
    d = OUT / "kpx_power_source"
    d.mkdir(parents=True, exist_ok=True)
    s, csrf = ps.session()
    for m in pd.period_range(start, end, freq="M"):
        out = d / f"ps_{m.strftime('%Y%m')}.xlsx"
        if out.exists():
            continue
        a, b = m.start_time.date(), m.end_time.date()
        content = ps.fetch_month(s, csrf, a, b)
        if not content.startswith(b"PK"):
            s, csrf = ps.session()
            content = ps.fetch_month(s, csrf, a, b)
        out.write_bytes(content)
        print(f"발전원별 {m.strftime('%Y%m')}: {len(content):,} bytes", flush=True)
        time.sleep(1)


def warn(start: str = "2022-12-01", end: str | None = None):
    """특보 발표 이력: 월 단위로 받아 원문 저장 → wrn_{YYYYMM}.txt"""
    end = end or date.today().isoformat()
    d = OUT / "kma_warning"
    d.mkdir(parents=True, exist_ok=True)
    key = os.environ["KMA_APIHUB_KEY"]   # common.config가 .env를 읽음
    for m in pd.period_range(start, end, freq="M"):
        out = d / f"wrn_{m.strftime('%Y%m')}.txt"
        if out.exists() and m < pd.Period(date.today(), "M"):
            continue
        r = requests.get("https://apihub.kma.go.kr/api/typ01/url/wrn_met_data.php",
                         params={"wrn": "A", "reg": "0", "tmfc1": f"{m.start_time.strftime('%Y%m%d')}0000",
                                 "tmfc2": f"{m.end_time.strftime('%Y%m%d')}2359", "disp": "0", "help": "1", "authKey": key},
                         timeout=120)
        r.raise_for_status()
        out.write_bytes(r.content)
        print(f"특보 {m.strftime('%Y%m')}: {len(r.content):,} bytes", flush=True)
        time.sleep(0.5)


if __name__ == "__main__":
    for job in (sys.argv[1:] or ["supply", "source", "warn"]):
        globals()[job]()
